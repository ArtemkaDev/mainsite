# @aplocoin/ui

Aplo's React 19 theme and compositions build on [UI SDK](https://ui-sdk.dev/docs/react). The theme covers the full 55-entry React component index. Import primitives directly from the SDK, then compose them for your product.

## Install

From the design system repository root, run `npm pack -w @aplocoin/ui`. Copy the archive into an app using React and React DOM 19.2 or later in the 19.x series and run:

```sh
npm install ./aplocoin-ui-0.5.4.tgz @ui-sdk/react@0.1.0-beta.13 @ui-sdk/core@0.1.0-beta.13
```

Import the stylesheet once in the app entry point or root layout. It includes the theme for base components and the styles for Aplo components.

```ts
import '@aplocoin/ui/styles.css'
```

Import base components from their specific `@ui-sdk/react/<component>` entries. Import Aplo compositions, shared Aplo controls and their types from `@aplocoin/ui`.

```tsx
import { Button, TextField } from '@aplocoin/ui'

export function WalletConnect({ onConnect }: { onConnect: () => void }) {
  return (
    <div data-aplo-theme="light">
      <TextField label="Wallet address" name="address" placeholder="0x…" />
      <Button onClick={onConnect}>Connect Wallet</Button>
    </div>
  )
}
```

Apps that only use base components can load `@aplocoin/ui/sdk.css` as their single stylesheet.

Set `data-aplo-theme` to `light`, `dark` or `system` on the document root or a container. The default theme is light. The preview app defaults to dark. For Vite development, add `'@aplocoin/ui'` to `optimizeDeps.exclude` so Vite resolves the package's local asset URLs against its source files. See the preview's Vite config for an example.

## Exports

| Entry | Use |
| --- | --- |
| `@aplocoin/ui` | React components, patterns, asset URLs and TypeScript types |
| `@aplocoin/ui/sdk.css` | Aplo theme for all UI SDK React primitives, plus Inter and the foundation styles |
| `@aplocoin/ui/styles.css` | The same theme plus Aplo components and compositions |
| `@aplocoin/ui/foundation.css` | Framework-independent layout and typography classes |
| `@aplocoin/ui/tokens.css` | Scoped CSS custom properties |
| `@aplocoin/ui/tokens.json` | Token values and source annotations |
| `@aplocoin/ui/assets/*` | Local icons and brand artwork |

Use `--aplo-action`, `--aplo-action-text`, `--aplo-muted` and `--aplo-control-border` for interactive surfaces. `--aplo-brand` and the tokens with a `-source` suffix preserve Figma values for reference and brand use.

## Components

| Area | Exports |
| --- | --- |
| Layout | `Container`, `Stack`, `Inline`, `Grid`, `PageHeading`, `Separator` |
| Navigation | `TextLink`, `LinkButton`, `NavLinks`, `Breadcrumbs`, `Pagination` |
| Actions and forms | `Button`, `IconButton`, `FieldFrame`, `TextField`, `TextareaField`, `SelectField`, `NumberField` |
| Menu and disclosure | `ActionMenu`, `Tooltip`, `DisclosureGroup` |
| Status and data | `Status`, `Alert`, `EmptyState`, `Skeleton`, `ProgressBar`, `MeterBar`, `DataTable`, `DescriptionList`, `MetricCard` |
| Selection | `ChoiceGroup`, `Checkbox`, `Switch`, `TabGroup` |
| Surfaces and feedback | `Card`, `CardHeading`, `Modal`, `ModalClose`, `Badge`, `Notification`, `Toaster`, `createToaster` |
| Brand | `Icon`, `Wordmark`, `Partners` |
| Wallet | `WalletHeader`, `ConnectWalletCard`, `ContractAddressCard`, `WalletSummary`, `TransactionHistory` |
| Web3 | `WalletConnectDialog`, `WalletAccount`, `NetworkBadge`, `NetworkSwitcher`, `WrongNetworkNotice`, `TransactionReviewDialog`, `TransactionStatus` |
| Swap and confirmation | `SwapCard`, `AmountPanel`, `TokenPicker`, `TokenRow`, `AddressForm`, `WithdrawalDetails`, `SuccessDialog`, `Congratulations` |
| Settings | `PreferencesCard`, `PreferencesDialog`, `PreferenceFields` |

Wallet flows accept callbacks and token data. Connect them to your wallet, quoting and transaction services in the consuming app. Address fields validate the hexadecimal format; chain lookup and checksum policy belong to the consumer.

Use `NumberField` for quantities such as block counts. Keep exact token amounts as strings and use the consuming app’s fixed-point conversion.

## Web3 integration

Import `@aplocoin/ui/styles.css`, then pass connector options and the state from your wallet service into `WalletConnectDialog`. Its `onConnect` callback receives the selected connector ID. Set `connection` to `connecting` while the wallet prompt is open, show a rejected request with `error`, and close the controlled dialog after the account is available. Render `WalletAccount` with that account and the active network.

Pass the confirmed chain into `NetworkSwitcher` as `activeId` and set `pendingId` while a switch is in progress. For an injected wallet, the consuming app can read the accounts and chain via its [EIP-1193 provider](https://eips.ethereum.org/EIPS/eip-1193) and supply discovered providers as options.

Use `TransactionReviewDialog` for the recipient, exact amounts and fee estimates. Its callback starts the app's wallet request. Update `TransactionStatus` from the signing result and transaction receipt. Supply an HTTP(S) explorer link when available.

For the native API and semantics of each primitive, see the [UI SDK React index](https://ui-sdk.dev/docs/react/components). The catalog in this repository shows each primitive using the published Aplo theme. Overlay motion follows UI SDK lifecycle states and the user’s reduced-motion preference.
